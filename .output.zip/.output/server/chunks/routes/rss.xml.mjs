import { d as defineEventHandler } from '../runtime.mjs';
import RSS from 'rss';
import showdown from 'showdown';
import { join } from 'path';
import { readFile } from 'fs/promises';
import 'node:http';
import 'node:https';
import 'fs';
import 'node:fs';
import 'node:url';
import 'shiki/core';
import '@shikijs/transformers';
import 'unified';
import 'mdast-util-to-string';
import 'micromark';
import 'unist-util-stringify-position';
import 'micromark-util-character';
import 'micromark-util-chunked';
import 'micromark-util-resolve-all';
import 'micromark-util-sanitize-uri';
import 'slugify';
import 'remark-parse';
import 'remark-rehype';
import 'remark-mdc';
import 'hast-util-to-string';
import 'github-slugger';
import 'detab';
import 'remark-emoji';
import 'remark-gfm';
import 'rehype-external-links';
import 'rehype-sort-attribute-values';
import 'rehype-sort-attributes';
import 'rehype-raw';

const SITE_URL = "http://josenong.top";
new showdown.Converter();
const rss_xml = defineEventHandler(async (event) => {
  var _a;
  const feed = new RSS({
    title: "My Site",
    site_url: SITE_URL,
    feed_url: SITE_URL + "/rss.xml"
  });
  const blogPosts = [];
  const converter2 = new showdown.Converter();
  for (const doc of blogPosts) {
    const filename = join(process.cwd(), "content", doc._file);
    const markdownText = await readFile(filename, "utf8");
    let contentWithoutFrontmatter = markdownText;
    const frontmatterEndIndex = markdownText.indexOf("---", 3);
    if (frontmatterEndIndex !== -1) {
      contentWithoutFrontmatter = markdownText.slice(frontmatterEndIndex + 3).trim();
    }
    const html = converter2.makeHtml(contentWithoutFrontmatter);
    feed.item({
      title: (_a = doc.title) != null ? _a : "-",
      url: `${SITE_URL}${doc._path}`,
      date: doc.createdAt,
      description: doc.description,
      custom_elements: [
        { "content:encoded": { _cdata: html } }
      ]
    });
  }
  event.res.setHeader("content-type", "text/xml");
  event.res.end(feed.xml({ indent: true }));
});

export { rss_xml as default };
//# sourceMappingURL=rss.xml.mjs.map
