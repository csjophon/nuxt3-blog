// ROLLUP_NO_REPLACE 
 const contentNavigation = "[{\"title\":\"如何做一个这样的网站？\",\"_path\":\"/website\",\"desc\":\"从大学开始，我就想写一个属于自己的博客网站了，一开始跟着B站部署了Hexo开源模板博客，后面又跟着部署了一个Vuepress的，后面自己想写一个全面一点的网站，不单单只博客，还包括一些项目啥的，第三个网站是看了antfu的网站后，看见他开源了，然后整体框架也是学习他的，后面自己融入了很多自己的东西，然后太乱了。直到现在，这个就是第四个博客网站了，只想用来做博客捏。\",\"date\":\"2024-03-31T00:00:00.000Z\",\"subtitle\":\"Jory Joestar的奇妙之旅\",\"type\":null}]";

export { contentNavigation as default };
//# sourceMappingURL=content-navigation.mjs.map
