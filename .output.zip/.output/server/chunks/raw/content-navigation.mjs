// ROLLUP_NO_REPLACE 
 const contentNavigation = "[{\"title\":\"Life\",\"_path\":\"/life\",\"children\":[{\"title\":\"Think\",\"_path\":\"/life/think\",\"children\":[{\"title\":\"为什么我写不出东西\",\"_path\":\"/life/think/think-01-24-04-13\",\"desc\":\"随着年龄的增长和时代的变化，越来越多的信息进入脑子，离开脑子，有些时候明明很多东西很想表达，但是却迟迟不能下笔。我作为天天与AI打交道的互联网工作者，AI越来越在我的工具中占据主动地位，让我渐渐放下独立的思考。\",\"date\":\"2024-04-13T00:00:00.000Z\",\"subtitle\":\"我是一个独立的个体\",\"type\":null,\"top\":false}]}]},{\"title\":\"如何做一个这样的网站\",\"_path\":\"/website\",\"desc\":\"从大学开始，我就想写一个属于自己的博客网站了，一开始跟着B站部署了Hexo开源模板博客，后面又跟着部署了一个Vuepress的，后面自己想写一个全面一点的网站，不单单只博客，还包括一些项目啥的，第三个网站是看了antfu的网站后，看见他开源了，然后整体框架也是学习他的，后面自己融入了很多自己的东西，然后太乱了。直到现在，这个就是第四个博客网站了，只想用来做博客捏。\",\"date\":\"2024-03-31T00:00:00.000Z\",\"subtitle\":\"Jory Joestar的奇妙之旅\",\"type\":null,\"top\":false}]";

export { contentNavigation as default };
//# sourceMappingURL=content-navigation.mjs.map
