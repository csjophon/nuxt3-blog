// ROLLUP_NO_REPLACE 
 const bookshelf = "{\"parsed\":{\"_path\":\"/bookshelf\",\"_dir\":\"\",\"_draft\":false,\"_partial\":false,\"_locale\":\"\",\"title\":\"书香\",\"description\":\"\",\"draft\":false,\"navigation\":true,\"head\":{\"meta\":[{\"name\":\"author\",\"content\":\"Jory\"},{\"name\":\"copyright\",\"content\":\"© 2024 Jory\"}]},\"subtitle\":null,\"desc\":null,\"date\":\"2077-01-01T00:00:00.000Z\",\"type\":null,\"top\":true,\"lang\":\"zh\",\"body\":{\"type\":\"root\",\"children\":[],\"toc\":{\"title\":\"\",\"searchDepth\":2,\"depth\":2,\"links\":[]}},\"_type\":\"markdown\",\"_id\":\"content:bookshelf.md\",\"_source\":\"content\",\"_file\":\"bookshelf.md\",\"_extension\":\"md\"},\"hash\":\"44JLqX5PfG\"}";

export { bookshelf as default };
//# sourceMappingURL=bookshelf.mjs.map
