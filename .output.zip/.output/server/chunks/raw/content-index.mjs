// ROLLUP_NO_REPLACE 
 const contentIndex = "{\"/website\":[\"content:website.md\"]}";

export { contentIndex as default };
//# sourceMappingURL=content-index.mjs.map
