// ROLLUP_NO_REPLACE 
 const contentIndex = "{\"/website\":[\"content:website.md\"],\"/short/24-04-17-short1\":[\"content:short:24-04-17-short1.md\"],\"/life/think/think-01-24-04-13\":[\"content:life:think:think-01-24-04-13.md\"]}";

export { contentIndex as default };
//# sourceMappingURL=content-index.mjs.map
