// ROLLUP_NO_REPLACE 
 const contentIndex = "{\"/favoraites\":[\"content:favoraites.md\"],\"/website\":[\"content:website.md\"]}";

export { contentIndex as default };
//# sourceMappingURL=content-index.mjs.map
