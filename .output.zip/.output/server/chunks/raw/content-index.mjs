// ROLLUP_NO_REPLACE 
 const contentIndex = "{\"/website\":[\"content:website.md\"],\"/life/think\":[\"content:life:think:为什么我写不出东西.md\"]}";

export { contentIndex as default };
//# sourceMappingURL=content-index.mjs.map
