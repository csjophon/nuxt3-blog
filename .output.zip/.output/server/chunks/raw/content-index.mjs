// ROLLUP_NO_REPLACE 
 const contentIndex = "{\"/bookshelf\":[\"content:bookshelf.md\"],\"/create\":[\"content:create.md\"],\"/favoraites\":[\"content:favoraites.md\"],\"/game\":[\"content:game.md\"],\"/music\":[\"content:music.md\"],\"/see\":[\"content:see.md\"],\"/website\":[\"content:website.md\"]}";

export { contentIndex as default };
//# sourceMappingURL=content-index.mjs.map
