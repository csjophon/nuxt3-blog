// ROLLUP_NO_REPLACE 
 const music = "{\"parsed\":{\"_path\":\"/music\",\"_dir\":\"\",\"_draft\":false,\"_partial\":false,\"_locale\":\"\",\"title\":\"悦耳\",\"description\":\"\",\"draft\":false,\"navigation\":true,\"head\":{\"meta\":[{\"name\":\"author\",\"content\":\"Jory\"},{\"name\":\"copyright\",\"content\":\"© 2024 Jory\"}]},\"subtitle\":null,\"desc\":null,\"date\":\"2077-03-01T00:00:00.000Z\",\"type\":null,\"top\":true,\"lang\":\"zh\",\"body\":{\"type\":\"root\",\"children\":[{\"type\":\"element\",\"tag\":\"h3\",\"props\":{\"id\":\"演说家\"},\"children\":[{\"type\":\"text\",\"value\":\"《演说家》\"}]}],\"toc\":{\"title\":\"\",\"searchDepth\":2,\"depth\":2,\"links\":[{\"id\":\"演说家\",\"depth\":3,\"text\":\"《演说家》\"}]}},\"_type\":\"markdown\",\"_id\":\"content:music.md\",\"_source\":\"content\",\"_file\":\"music.md\",\"_extension\":\"md\"},\"hash\":\"e6ap2eQtiC\"}";

export { music as default };
//# sourceMappingURL=music.mjs.map
