// ROLLUP_NO_REPLACE 
 const _240417Short1 = "{\"parsed\":{\"_path\":\"/short/24-04-17-short1\",\"_dir\":\"short\",\"_draft\":false,\"_partial\":false,\"_locale\":\"\",\"title\":\"24 04 17 Short1\",\"description\":\"\",\"draft\":false,\"navigation\":true,\"head\":{\"meta\":[{\"name\":\"author\",\"content\":\"Jory\"},{\"name\":\"copyright\",\"content\":\"© 2024 Jory\"}]},\"date\":\"2024-04-17T00:00:00.000Z\",\"subtitle\":null,\"desc\":\"新工作已经工作一个半月，但没啥感觉，有感觉也只有一种有力使不出，确实打工人终究只能是打工，不用妄想自己是主角，我要跳脱出来，做好分内事之外努力学习，我总有一种feel，我要厚积薄发！\",\"type\":null,\"top\":false,\"favorites\":false,\"short\":true,\"lang\":\"zh\",\"body\":{\"type\":\"root\",\"children\":[],\"toc\":{\"title\":\"\",\"searchDepth\":2,\"depth\":2,\"links\":[]}},\"_type\":\"markdown\",\"_id\":\"content:short:24-04-17-short1.md\",\"_source\":\"content\",\"_file\":\"short/24-04-17-short1.md\",\"_extension\":\"md\"},\"hash\":\"gkxBF9Cbbb\"}";

export { _240417Short1 as default };
//# sourceMappingURL=24-04-17-short1.mjs.map
