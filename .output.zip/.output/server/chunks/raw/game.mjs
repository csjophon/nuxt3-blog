// ROLLUP_NO_REPLACE 
 const game = "{\"parsed\":{\"_path\":\"/game\",\"_dir\":\"\",\"_draft\":false,\"_partial\":false,\"_locale\":\"\",\"title\":\"游戏\",\"description\":\"\",\"draft\":false,\"navigation\":true,\"head\":{\"meta\":[{\"name\":\"author\",\"content\":\"Jory\"},{\"name\":\"copyright\",\"content\":\"© 2024 Jory\"}]},\"subtitle\":null,\"desc\":null,\"date\":\"2077-01-01T00:00:00.000Z\",\"type\":null,\"top\":true,\"lang\":\"zh\",\"body\":{\"type\":\"root\",\"children\":[],\"toc\":{\"title\":\"\",\"searchDepth\":2,\"depth\":2,\"links\":[]}},\"_type\":\"markdown\",\"_id\":\"content:game.md\",\"_source\":\"content\",\"_file\":\"game.md\",\"_extension\":\"md\"},\"hash\":\"6kCzgf8E2c\"}";

export { game as default };
//# sourceMappingURL=game.mjs.map
