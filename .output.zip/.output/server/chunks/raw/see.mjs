// ROLLUP_NO_REPLACE 
 const see = "{\"parsed\":{\"_path\":\"/see\",\"_dir\":\"\",\"_draft\":false,\"_partial\":false,\"_locale\":\"\",\"title\":\"乐视\",\"description\":\"\",\"draft\":false,\"navigation\":true,\"head\":{\"meta\":[{\"name\":\"author\",\"content\":\"Jory\"},{\"name\":\"copyright\",\"content\":\"© 2024 Jory\"}]},\"subtitle\":null,\"desc\":null,\"date\":\"2077-04-01T00:00:00.000Z\",\"type\":null,\"top\":true,\"lang\":\"zh\",\"body\":{\"type\":\"root\",\"children\":[{\"type\":\"element\",\"tag\":\"h2\",\"props\":{\"id\":\"动漫\"},\"children\":[{\"type\":\"text\",\"value\":\"动漫\"}]}],\"toc\":{\"title\":\"\",\"searchDepth\":2,\"depth\":2,\"links\":[{\"id\":\"动漫\",\"depth\":2,\"text\":\"动漫\"}]}},\"_type\":\"markdown\",\"_id\":\"content:see.md\",\"_source\":\"content\",\"_file\":\"see.md\",\"_extension\":\"md\"},\"hash\":\"1NTxKYkWri\"}";

export { see as default };
//# sourceMappingURL=see.mjs.map
