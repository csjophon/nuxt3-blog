// ROLLUP_NO_REPLACE 
 const see = "{\"parsed\":{\"_path\":\"/see\",\"_dir\":\"\",\"_draft\":false,\"_partial\":false,\"_locale\":\"\",\"title\":\"乐视\",\"description\":\"\",\"draft\":false,\"navigation\":true,\"head\":{\"meta\":[{\"name\":\"author\",\"content\":\"Jory\"},{\"name\":\"copyright\",\"content\":\"© 2024 Jory\"}]},\"subtitle\":null,\"desc\":null,\"date\":\"2077-04-01T00:00:00.000Z\",\"type\":null,\"top\":true,\"lang\":\"zh\",\"body\":{\"type\":\"root\",\"children\":[],\"toc\":{\"title\":\"\",\"searchDepth\":2,\"depth\":2,\"links\":[]}},\"_type\":\"markdown\",\"_id\":\"content:see.md\",\"_source\":\"content\",\"_file\":\"see.md\",\"_extension\":\"md\"},\"hash\":\"t06CEY3Nsu\"}";

export { see as default };
//# sourceMappingURL=see.mjs.map
