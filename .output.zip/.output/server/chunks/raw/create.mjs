// ROLLUP_NO_REPLACE 
 const create = "{\"parsed\":{\"_path\":\"/create\",\"_dir\":\"\",\"_draft\":false,\"_partial\":false,\"_locale\":\"\",\"title\":\"创造\",\"description\":\"\",\"draft\":false,\"navigation\":true,\"head\":{\"meta\":[{\"name\":\"author\",\"content\":\"Jory\"},{\"name\":\"copyright\",\"content\":\"© 2024 Jory\"}]},\"subtitle\":null,\"desc\":null,\"date\":\"2077-12-02T00:00:00.000Z\",\"type\":null,\"top\":true,\"lang\":\"zh\",\"body\":{\"type\":\"root\",\"children\":[{\"type\":\"element\",\"tag\":\"h2\",\"props\":{\"id\":\"minecraft-皮肤编辑器\"},\"children\":[{\"type\":\"text\",\"value\":\"Minecraft 皮肤编辑器\"}]}],\"toc\":{\"title\":\"\",\"searchDepth\":2,\"depth\":2,\"links\":[{\"id\":\"minecraft-皮肤编辑器\",\"depth\":2,\"text\":\"Minecraft 皮肤编辑器\"}]}},\"_type\":\"markdown\",\"_id\":\"content:create.md\",\"_source\":\"content\",\"_file\":\"create.md\",\"_extension\":\"md\"},\"hash\":\"4LhFPkjO6S\"}";

export { create as default };
//# sourceMappingURL=create.mjs.map
