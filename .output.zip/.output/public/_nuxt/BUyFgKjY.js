import{f as n,ac as e}from"./CMwZll7j.js";const t=n({name:"DocumentDrivenNotFound",render(){return e("div","Document not found")}});export{t as default};
