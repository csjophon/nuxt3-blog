const a={},e={},c=()=>({legacy:!1,locale:"zh",fallbackLocale:"zh",messages:{en:a,zh:e}});export{c as default};
