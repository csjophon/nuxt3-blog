import{_ as o,o as r,c as s,A as t}from"./Bhe5t-ev.js";const c={};function n(e,a){return r(),s("li",null,[t(e.$slots,"default")])}const _=o(c,[["render",n]]);export{_ as default};
