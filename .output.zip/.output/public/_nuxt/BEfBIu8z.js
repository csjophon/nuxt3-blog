import{_ as o,o as r,c as s,G as t}from"./D6AYyMoD.js";const c={};function n(e,l){return r(),s("ul",null,[t(e.$slots,"default")])}const _=o(c,[["render",n]]);export{_ as default};
