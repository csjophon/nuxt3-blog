import{_ as o,o as n,c as r,I as c}from"./_yt6cuUF.js";const s={};function t(e,a){return n(),r("code",null,[c(e.$slots,"default")])}const _=o(s,[["render",t]]);export{_ as default};
