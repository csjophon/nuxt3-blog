import{f as n,a9 as e}from"./CXpb5L0V.js";const t=n({name:"DocumentDrivenNotFound",render(){return e("div","Document not found")}});export{t as default};
