import{_ as o,o as r,c as s,I as t}from"./_yt6cuUF.js";const c={};function n(e,a){return r(),s("p",null,[t(e.$slots,"default")])}const _=o(c,[["render",n]]);export{_ as default};
