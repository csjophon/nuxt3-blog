import{_ as r,o,c as t,I as s}from"./BK06h8fZ.js";const c={};function n(e,a){return o(),t("tr",null,[s(e.$slots,"default")])}const _=r(c,[["render",n]]);export{_ as default};
