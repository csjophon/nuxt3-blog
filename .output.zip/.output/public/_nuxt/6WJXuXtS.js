import{_ as o,o as r,c as t,J as s}from"./CMwZll7j.js";const c={};function n(e,a){return r(),t("tbody",null,[s(e.$slots,"default")])}const _=o(c,[["render",n]]);export{_ as default};
