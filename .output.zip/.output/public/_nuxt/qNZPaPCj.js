import{_ as o,o as r,c as s,I as t}from"./BK06h8fZ.js";const c={};function n(e,l){return r(),s("ul",null,[t(e.$slots,"default")])}const _=o(c,[["render",n]]);export{_ as default};
