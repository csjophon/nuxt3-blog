import{_ as o,o as r,c as t,I as n}from"./_yt6cuUF.js";const s={};function c(e,a){return r(),t("strong",null,[n(e.$slots,"default")])}const _=o(s,[["render",c]]);export{_ as default};
