import{_ as e,o as r,c}from"./PPuHCLgd.js";const o={};function t(n,s){return r(),c("hr")}const a=e(o,[["render",t]]);export{a as default};
