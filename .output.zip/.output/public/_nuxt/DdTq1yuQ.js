import{f as n,aa as e}from"./BK06h8fZ.js";const t=n({name:"DocumentDrivenNotFound",render(){return e("div","Document not found")}});export{t as default};
