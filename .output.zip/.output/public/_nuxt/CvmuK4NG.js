import{_ as o,o as t,c,A as r}from"./Bhe5t-ev.js";const s={};function n(e,l){return t(),c("blockquote",null,[r(e.$slots,"default")])}const _=o(s,[["render",n]]);export{_ as default};
