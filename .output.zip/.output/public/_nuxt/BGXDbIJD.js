import{_ as o,o as r,c as t,J as s}from"./CMwZll7j.js";const a={};function c(e,n){return r(),t("thead",null,[s(e.$slots,"default")])}const _=o(a,[["render",c]]);export{_ as default};
