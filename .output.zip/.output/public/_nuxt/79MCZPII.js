import{f as n,a9 as e}from"./UJiK-3Zc.js";const t=n({name:"DocumentDrivenNotFound",render(){return e("div","Document not found")}});export{t as default};
