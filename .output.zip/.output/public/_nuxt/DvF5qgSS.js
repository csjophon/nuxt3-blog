import{_ as o,o as r,c as t,I as n}from"./PPuHCLgd.js";const s={};function c(e,a){return r(),t("strong",null,[n(e.$slots,"default")])}const _=o(s,[["render",c]]);export{_ as default};
