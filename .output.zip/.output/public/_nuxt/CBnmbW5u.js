import{_ as o,o as n,c as r,I as c}from"./BK06h8fZ.js";const s={};function t(e,a){return n(),r("code",null,[c(e.$slots,"default")])}const _=o(s,[["render",t]]);export{_ as default};
