import{_ as o,o as r,c as t,I as s}from"./BqfWCigh.js";const c={};function n(e,a){return r(),t("th",null,[s(e.$slots,"default")])}const _=o(c,[["render",n]]);export{_ as default};
